const STORAGE_KEY = "notes-app-items";
const form = document.querySelector("#note-form");
const titleInput = document.querySelector("#note-title");
const bodyInput = document.querySelector("#note-body");
const notesContainer = document.querySelector("#notes");
const emptyMessage = document.querySelector("#empty");

let notes = readNotes();

function readNotes() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

function render() {
  notesContainer.replaceChildren();
  emptyMessage.hidden = notes.length > 0;

  notes.forEach(note => {
    const card = document.createElement("article");
    card.className = "note";
    const title = document.createElement("h3");
    title.textContent = note.title;
    const body = document.createElement("p");
    body.textContent = note.body;
    const footer = document.createElement("footer");
    const date = document.createElement("time");
    date.textContent = new Date(note.createdAt).toLocaleDateString("ru-RU");
    const remove = document.createElement("button");
    remove.className = "delete";
    remove.type = "button";
    remove.textContent = "Удалить";
    remove.addEventListener("click", () => {
      notes = notes.filter(item => item.id !== note.id);
      persist();
      render();
    });
    footer.append(date, remove);
    card.append(title, body, footer);
    notesContainer.append(card);
  });
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const title = titleInput.value.trim();
  const body = bodyInput.value.trim();
  if (!title || !body) return;

  notes.unshift({ id: crypto.randomUUID(), title, body, createdAt: new Date().toISOString() });
  persist();
  render();
  form.reset();
  titleInput.focus();
});

render();
