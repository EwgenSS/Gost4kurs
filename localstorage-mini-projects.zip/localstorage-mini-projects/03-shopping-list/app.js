const STORAGE_KEY = "shopping-list-items";
const form = document.querySelector("#item-form");
const input = document.querySelector("#item-input");
const list = document.querySelector("#items");
const summary = document.querySelector("#summary");
const clearButton = document.querySelector("#clear-all");

let items = readItems();

function readItems() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

function render() {
  list.replaceChildren();
  items.forEach(item => {
    const row = document.createElement("li");
    if (item.checked) row.classList.add("checked");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = item.checked;
    checkbox.setAttribute("aria-label", `Куплено: ${item.name}`);
    checkbox.addEventListener("change", () => {
      item.checked = checkbox.checked;
      save();
      render();
    });

    const name = document.createElement("span");
    name.textContent = item.name;

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "remove";
    remove.textContent = "Удалить";
    remove.addEventListener("click", () => {
      items = items.filter(entry => entry.id !== item.id);
      save();
      render();
    });

    row.append(checkbox, name, remove);
    list.append(row);
  });

  const bought = items.filter(item => item.checked).length;
  summary.textContent = `${items.length} товаров · куплено: ${bought}`;
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const name = input.value.trim();
  if (!name) return;
  items.push({ id: crypto.randomUUID(), name, checked: false });
  save();
  render();
  form.reset();
  input.focus();
});

clearButton.addEventListener("click", () => {
  items = [];
  save();
  render();
});

render();
